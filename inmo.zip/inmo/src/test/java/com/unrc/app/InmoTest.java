package com.unrc.app;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.*;


@SuppressWarnings("unused")
public class InmoTest {

    @Test
    public void testTest(){
        assertEquals(10, 10);
    }

}